<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>PHP with two paremeters</h2>
    <?PHP
    /*Defining a PHP Function*/
    function addFunction($sum1, $sum2): void{
            $sum = $sum1 + $sum2;
        echo "Sum of the two numbers is : $sum";
    } 
    /*Calling a PHP Function*/
    addFunction(10,20);
    ?>
</body>
</html>