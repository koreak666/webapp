<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Passing Arguments by Reference</h2>
    <?PHP
    /*Defining a PHP addFive Function*/
    function addFive($num): void{
        $num += 5;
    } 
    /*Defining a PHP addSixFunction*/

    /*add & it means pass by reference*/
    function addSix(&$num): void{
        $num += 6;
    }
    /*Define original number*/
    $origum = 10;
    addFive($origum);
    /*show result of addFive by value*/
    echo " Original Value is $origum <br />";

    $origum = 10;
    addSix($origum);
    /*show result of addSix by value*/
    echo " Original Value is $origum <br />";
    ?>
</body>
</html>