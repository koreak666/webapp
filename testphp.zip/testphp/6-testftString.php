<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Dynamic Function Calls</h2>
    <?PHP
        function sayHello() {
            echo "Hello Com Sci<br />";
        }
      
      $function_holder = "sayHello";
      $function_holder();
      sayHello();
    ?>
</body>
</html>