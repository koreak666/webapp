<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
function test($s){
    $count = 0;

    for ($i = 0; $i < strlen($s) - 1; $i++) {
        if (substr($s, $i, 2) == "aa") {
            $count++;
        }
    }
    return $count;
}
echo test("bbaacccaag") . "<br>";
echo test("jjkiaaasew") . "<br>";
echo test("JSaaaioaa") . "<br>";
?>
</body>
</html>