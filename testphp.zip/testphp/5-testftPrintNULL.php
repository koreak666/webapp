<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Write PHP Functions which returning value</h2>
    <?PHP
        function printMe($param = NULL) {
            print $param;
        }
      printMe("This is Test");
      printMe();
      printMe("<br />This is Test");
      printMe();printMe();
    ?>
</body>
</html>